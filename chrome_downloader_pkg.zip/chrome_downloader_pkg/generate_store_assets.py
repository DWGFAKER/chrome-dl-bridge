import os
from PIL import Image, ImageDraw, ImageFont

ASSETS_DIR = r"D:\article4\scratch\chrome_downloader_pkg\store_assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

FONT_PATH = r"C:\Windows\Fonts\msyh.ttc"
FONT_BOLD_PATH = r"C:\Windows\Fonts\msyhbd.ttc"

def get_font(size, bold=False):
    try:
        path = FONT_BOLD_PATH if bold else FONT_PATH
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()

def draw_rounded_rect(draw, bbox, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(bbox, radius=radius, fill=fill, outline=outline, width=width)

def create_screenshot_1():
    # 1280x800 - Popup & Overview
    img = Image.new("RGB", (1280, 800), color=(240, 244, 248))
    draw = ImageDraw.Draw(img)

    # Top Hero Banner / Header
    draw.rectangle([0, 0, 1280, 100], fill=(24, 32, 47))
    f_title = get_font(34, bold=True)
    f_sub = get_font(18, bold=False)
    draw.text((60, 24), "chrome-dl-bridge · Chrome 原生下载桥", fill=(255, 255, 255), font=f_title)
    draw.text((60, 64), "零配置免开服 · 100% 走浏览器网络栈 · 自动继承 Cookie、代理与加速器", fill=(160, 178, 204), font=f_sub)

    # Badge on right
    draw_rounded_rect(draw, [1060, 32, 1220, 68], 8, fill=(37, 99, 235))
    f_badge = get_font(16, bold=True)
    draw.text((1082, 40), "Manifest V3", fill=(255, 255, 255), font=f_badge)

    # Browser Mockup Frame
    b_left, b_top, b_right, b_bottom = 60, 130, 1220, 740
    draw_rounded_rect(draw, [b_left, b_top, b_right, b_bottom], 12, fill=(255, 255, 255), outline=(203, 213, 225), width=2)

    # Browser Tab Bar
    draw.rectangle([b_left, b_top, b_right, b_top + 44], fill=(235, 240, 246))
    draw.ellipse([b_left + 16, b_top + 16, b_left + 28, b_top + 28], fill=(239, 68, 68))
    draw.ellipse([b_left + 36, b_top + 16, b_left + 48, b_top + 28], fill=(245, 158, 11))
    draw.ellipse([b_left + 56, b_top + 16, b_left + 68, b_top + 28], fill=(16, 185, 129))

    # Active Tab
    draw_rounded_rect(draw, [b_left + 90, b_top + 8, b_left + 280, b_top + 44], 6, fill=(255, 255, 255))
    f_tab = get_font(14, bold=False)
    draw.text((b_left + 110, b_top + 16), "Chrome 扩展中心", fill=(51, 65, 85), font=f_tab)

    # Address bar
    draw.rectangle([b_left, b_top + 44, b_right, b_top + 88], fill=(255, 255, 255), outline=(226, 232, 240), width=1)
    draw_rounded_rect(draw, [b_left + 16, b_top + 52, b_right - 100, b_top + 80], 6, fill=(241, 245, 249))
    draw.text((b_left + 30, b_top + 57), "chrome://extensions/ · chrome-dl-bridge 状态已就绪", fill=(100, 116, 139), font=f_tab)

    # Extension Icon in toolbar
    draw_rounded_rect(draw, [b_right - 80, b_top + 50, b_right - 40, b_top + 82], 6, fill=(224, 231, 255))
    draw.text((b_right - 70, b_top + 56), "DL", fill=(67, 56, 202), font=get_font(14, bold=True))

    # Chrome Extension Popup (floating card)
    p_left, p_top, p_right, p_bottom = b_right - 440, b_top + 92, b_right - 20, b_top + 450
    draw_rounded_rect(draw, [p_left, p_top, p_right, p_bottom], 12, fill=(255, 255, 255), outline=(148, 163, 184), width=2)

    # Popup Header
    draw.rectangle([p_left, p_top, p_right, p_top + 50], fill=(248, 250, 252))
    f_card_title = get_font(16, bold=True)
    draw.text((p_left + 20, p_top + 15), "Chrome 下载桥 · 运行状态", fill=(30, 41, 59), font=f_card_title)
    draw_rounded_rect(draw, [p_right - 80, p_top + 12, p_right - 16, p_top + 38], 12, fill=(220, 252, 231))
    draw.text((p_right - 68, p_top + 16), "运行中", fill=(22, 101, 52), font=get_font(12, bold=True))

    # Popup Content lines
    f_label = get_font(14, bold=True)
    f_val = get_font(14, bold=False)
    y_cursor = p_top + 70

    items = [
        ("控制端口", "127.0.0.1:18888 (本地回环专用)"),
        ("连接模式", "RFC 6455 本地 WebSocket 链路"),
        ("认证保护", "双向非对称握手 (TOFU 安全校验)"),
        ("下载通道", "chrome.downloads 原生内核调度"),
        ("网络环境", "自动承载代理 / Cookie / 加速器"),
        ("后台服务", "按需自动拉起，无需人工管理")
    ]

    for label, val in items:
        draw_rounded_rect(draw, [p_left + 16, y_cursor, p_right - 16, y_cursor + 38], 6, fill=(248, 250, 252))
        draw.text((p_left + 26, y_cursor + 10), label, fill=(71, 85, 105), font=f_label)
        draw.text((p_left + 110, y_cursor + 10), val, fill=(15, 23, 42), font=f_val)
        y_cursor += 46

    # Left content inside browser window: Feature Highlights
    f_feat_h = get_font(24, bold=True)
    f_feat_body = get_font(16, bold=False)
    draw.text((b_left + 40, b_top + 130), "极简架构 · 安全纯粹", fill=(15, 23, 42), font=f_feat_h)

    bullets = [
        ("一键安装，永久省心", "安装本扩展后即可关闭管理页面，完全后台待命，无多余常驻图标。"),
        ("100% 流量在浏览器内部流转", "客户端只发送下载链接命令，所有文件字节流 100% 走 Chrome，不偷跑流量。"),
        ("原生适配 AI Agent 与脚本调用", "提供 Python SDK、命令行 CLI、MCP 工具，无缝集成主流 AI 编程助手。")
    ]

    b_y = b_top + 190
    for h, desc in bullets:
        draw.ellipse([b_left + 40, b_y + 6, b_left + 50, b_y + 16], fill=(37, 99, 235))
        draw.text((b_left + 64, b_y), h, fill=(30, 41, 59), font=get_font(18, bold=True))
        draw.text((b_left + 64, b_y + 32), desc, fill=(100, 116, 139), font=f_feat_body)
        b_y += 84

    img.save(os.path.join(ASSETS_DIR, "screenshot_1.png"), format="PNG")
    print("Screenshot 1 generated.")

def create_screenshot_2():
    # 1280x800 - AI Agent & MCP
    img = Image.new("RGB", (1280, 800), color=(240, 244, 248))
    draw = ImageDraw.Draw(img)

    # Top Hero Banner / Header
    draw.rectangle([0, 0, 1280, 100], fill=(24, 32, 47))
    f_title = get_font(34, bold=True)
    f_sub = get_font(18, bold=False)
    draw.text((60, 24), "AI Agent 原生集成 · 标准 MCP 协议", fill=(255, 255, 255), font=f_title)
    draw.text((60, 64), "无缝接入 Claude Code、Cursor、Paseo 等智能体，AI 一句话调度 Chrome 下载", fill=(160, 178, 204), font=f_sub)

    draw_rounded_rect(draw, [1050, 32, 1220, 68], 8, fill=(16, 185, 129))
    draw.text((1076, 40), "MCP Toolchain", fill=(255, 255, 255), font=get_font(16, bold=True))

    # Split Screen: Left AI Chat, Right Chrome Download
    # Left: AI Agent Window
    l_box = [60, 130, 620, 740]
    draw_rounded_rect(draw, l_box, 12, fill=(255, 255, 255), outline=(203, 213, 225), width=2)
    draw.rectangle([l_box[0], l_box[1], l_box[2], l_box[1] + 44], fill=(241, 245, 249))
    draw.text((l_box[0] + 20, l_box[1] + 12), "AI Agent 对话终端 (Claude Code / Cursor)", fill=(30, 41, 59), font=get_font(15, bold=True))

    # Chat Bubbles
    # User message
    draw_rounded_rect(draw, [l_box[0] + 20, l_box[1] + 65, l_box[2] - 20, l_box[1] + 140], 10, fill=(241, 245, 249))
    draw.text((l_box[0] + 36, l_box[1] + 78), "用户：", fill=(100, 116, 139), font=get_font(14, bold=True))
    draw.text((l_box[0] + 36, l_box[1] + 102), "帮我通过 Chrome 插件下载这个数据集并汇报进度：\nhttps://example.com/dataset_2026.tar.gz", fill=(15, 23, 42), font=get_font(14, bold=False))

    # Agent Thought & MCP Tool Call
    draw_rounded_rect(draw, [l_box[0] + 20, l_box[1] + 160, l_box[2] - 20, l_box[1] + 360], 10, fill=(248, 250, 252), outline=(226, 232, 240), width=1)
    draw.text((l_box[0] + 36, l_box[1] + 175), "AI Agent 调用 MCP 工具：", fill=(37, 99, 235), font=get_font(14, bold=True))

    code_bg = [l_box[0] + 36, l_box[1] + 205, l_box[2] - 36, l_box[1] + 335]
    draw.rectangle(code_bg, fill=(30, 41, 59))
    code_text = (
        "Tool: chrome-dl-mcp -> download_file\n"
        "Arguments: {\n"
        '  "url": "https://example.com/dataset_2026.tar.gz",\n'
        '  "wait": true\n'
        "}\n"
        ">> [Daemon] 自动唤醒后台通道，已派发至 Chrome"
    )
    draw.text((code_bg[0] + 16, code_bg[1] + 14), code_text, fill=(226, 232, 240), font=get_font(13, bold=False))

    # Agent Response
    draw_rounded_rect(draw, [l_box[0] + 20, l_box[1] + 380, l_box[2] - 20, l_box[1] + 560], 10, fill=(236, 253, 245), outline=(167, 243, 208), width=1)
    draw.text((l_box[0] + 36, l_box[1] + 395), "AI 回复：", fill=(5, 150, 105), font=get_font(14, bold=True))
    resp_text = (
        "已成功通过 Chrome 原生下载引擎完成任务！\n\n"
        "• 文件名称：dataset_2026.tar.gz\n"
        "• 传输大小：128.5 MB (100% 走浏览器网络栈)\n"
        "• 保存路径：C:\\Users\\User\\Downloads\\chrome-dl\\\n"
        "• 状态：COMPLETED\n"
        "• SHA256：9f83c18b... (校验无误)"
    )
    draw.text((l_box[0] + 36, l_box[1] + 425), resp_text, fill=(6, 78, 59), font=get_font(14, bold=False))

    # Right: Chrome Browser Native Download Shelf
    r_box = [660, 130, 1220, 740]
    draw_rounded_rect(draw, r_box, 12, fill=(255, 255, 255), outline=(203, 213, 225), width=2)
    draw.rectangle([r_box[0], r_box[1], r_box[2], r_box[1] + 44], fill=(241, 245, 249))
    draw.text((r_box[0] + 20, r_box[1] + 12), "Chrome 浏览器 · 原生下载接管", fill=(30, 41, 59), font=get_font(15, bold=True))

    # Native Download Card 1
    d_card1 = [r_box[0] + 24, r_box[1] + 70, r_box[2] - 24, r_box[1] + 180]
    draw_rounded_rect(draw, d_card1, 8, fill=(248, 250, 252), outline=(203, 213, 225), width=1)
    draw_rounded_rect(draw, [d_card1[0] + 16, d_card1[1] + 20, d_card1[0] + 64, d_card1[1] + 68], 6, fill=(224, 231, 255))
    draw.text((d_card1[0] + 26, d_card1[1] + 30), "ZIP", fill=(37, 99, 235), font=get_font(16, bold=True))
    draw.text((d_card1[0] + 80, d_card1[1] + 20), "dataset_2026.tar.gz", fill=(15, 23, 42), font=get_font(16, bold=True))
    draw.text((d_card1[0] + 80, d_card1[1] + 48), "128.5 MB · 已完成 · 自动继承系统代理与加速通道", fill=(100, 116, 139), font=get_font(13, bold=False))
    draw_rounded_rect(draw, [d_card1[2] - 110, d_card1[1] + 28, d_card1[2] - 20, d_card1[1] + 62], 4, fill=(220, 252, 231))
    draw.text((d_card1[2] - 96, d_card1[1] + 35), "下载成功", fill=(22, 101, 52), font=get_font(13, bold=True))

    # Download Card 2
    d_card2 = [r_box[0] + 24, r_box[1] + 200, r_box[2] - 24, r_box[1] + 310]
    draw_rounded_rect(draw, d_card2, 8, fill=(248, 250, 252), outline=(203, 213, 225), width=1)
    draw_rounded_rect(draw, [d_card2[0] + 16, d_card2[1] + 20, d_card2[0] + 64, d_card2[1] + 68], 6, fill=(254, 243, 199))
    draw.text((d_card2[0] + 24, d_card2[1] + 30), "CSV", fill=(217, 119, 6), font=get_font(16, bold=True))
    draw.text((d_card2[0] + 80, d_card2[1] + 20), "clinical_cohort_records.csv", fill=(15, 23, 42), font=get_font(16, bold=True))
    draw.text((d_card2[0] + 80, d_card2[1] + 48), "82.4 MB / 150 MB (14.2 MB/s) · 下载进行中...", fill=(100, 116, 139), font=get_font(13, bold=False))
    # progress bar
    draw.rectangle([d_card2[0] + 80, d_card2[1] + 75, d_card2[2] - 20, d_card2[1] + 85], fill=(226, 232, 240))
    draw.rectangle([d_card2[0] + 80, d_card2[1] + 75, d_card2[0] + 80 + 260, d_card2[1] + 85], fill=(37, 99, 235))

    # Architecture banner on right
    draw_rounded_rect(draw, [r_box[0] + 24, r_box[1] + 340, r_box[2] - 24, r_box[1] + 560], 8, fill=(240, 249, 255), outline=(186, 230, 253), width=1)
    draw.text((r_box[0] + 40, r_box[1] + 360), "为什么 AI Agent 必须使用它？", fill=(3, 105, 161), font=get_font(18, bold=True))
    agent_reasons = [
        "1. 免 Cookie 导出：直接利用浏览器现有登录会话",
        "2. 免代理重配：直接利用浏览器原生网络代理通道",
        "3. 全程自动拉起：Agent 发起指令即拉起后台控制服务",
        "4. 标准化输出：严格返回校验和与落盘文件绝对路径"
    ]
    ry = r_box[1] + 405
    for r in agent_reasons:
        draw.text((r_box[0] + 40, ry), r, fill=(14, 116, 144), font=get_font(14, bold=False))
        ry += 35

    img.save(os.path.join(ASSETS_DIR, "screenshot_2.png"), format="PNG")
    print("Screenshot 2 generated.")

def create_screenshot_3():
    # 1280x800 - CLI & Terminal Control
    img = Image.new("RGB", (1280, 800), color=(240, 244, 248))
    draw = ImageDraw.Draw(img)

    # Top Hero Banner / Header
    draw.rectangle([0, 0, 1280, 100], fill=(24, 32, 47))
    f_title = get_font(34, bold=True)
    f_sub = get_font(18, bold=False)
    draw.text((60, 24), "强大的命令行 CLI · 批量与自动化下载", fill=(255, 255, 255), font=f_title)
    draw.text((60, 64), "内置完整的守护进程管理、进度跟踪、断点续传与完整性校验", fill=(160, 178, 204), font=f_sub)

    draw_rounded_rect(draw, [1050, 32, 1220, 68], 8, fill=(99, 102, 241))
    draw.text((1078, 40), "CLI Toolchain", fill=(255, 255, 255), font=get_font(16, bold=True))

    # Terminal Frame
    t_left, t_top, t_right, t_bottom = 60, 130, 1220, 740
    draw_rounded_rect(draw, [t_left, t_top, t_right, t_bottom], 12, fill=(15, 23, 42), outline=(51, 65, 85), width=2)

    # Window Controls
    draw.rectangle([t_left, t_top, t_right, t_top + 40], fill=(30, 41, 59))
    draw.ellipse([t_left + 16, t_top + 14, t_left + 28, t_top + 26], fill=(239, 68, 68))
    draw.ellipse([t_left + 36, t_top + 14, t_left + 48, t_top + 26], fill=(245, 158, 11))
    draw.ellipse([t_left + 56, t_top + 14, t_left + 68, t_top + 26], fill=(16, 185, 129))
    draw.text((t_left + 90, t_top + 12), "Windows Terminal · chrome-dl 命令行控制台", fill=(148, 163, 184), font=get_font(14, bold=False))

    # Console Text Output
    console_lines = [
        ("$ pip install chrome-downloader", (148, 163, 184)),
        ("Successfully installed chrome-downloader-0.3.0", (34, 197, 94)),
        ("", (0, 0, 0)),
        ("$ chrome-dl download https://example.com/huge_model.bin --wait", (255, 255, 255)),
        ("[Daemon] 后台下载桥未启动，正在自动静默拉起...", (56, 189, 248)),
        ("[Daemon] 后台服务就绪 (PID 14208, 监听 127.0.0.1:18888)", (34, 197, 94)),
        ("[Bridge] 已与 Chrome 插件握手配对 (安全 TOFU 通道已建立)", (34, 197, 94)),
        ("[Chrome] 任务已分发至浏览器原生下载队列: job_a1f9e02c7b4d", (226, 232, 240)),
        ("[Progress] [========================================] 100% 4.2GB / 4.2GB (38.5 MB/s)", (56, 189, 248)),
        ("[Verify] 文件下载完毕，正在计算 SHA256 校验和...", (226, 232, 240)),
        ("[Success] 完成！落盘文件: C:\\Users\\User\\Downloads\\chrome-dl\\huge_model.bin", (34, 197, 94)),
        ("[Success] SHA256: 8f3c7e4b910a2d5f8c3e1b7a4d9e0f2c5a8b7e6d4c1a0f9e8d7c6b5a4f3e2d1c", (250, 204, 21)),
        ("", (0, 0, 0)),
        ("$ chrome-dl list", (255, 255, 255)),
        ("JOB_ID            STATE       PROGRESS    SPEED       FILENAME", (148, 163, 184)),
        ("job_a1f9e02c7b4d  COMPLETE    4.2GB/4.2GB 0 B/s       huge_model.bin", (226, 232, 240)),
        ("job_8b21c4091e7a  IN_PROGRESS 450MB/1.2GB 18.2 MB/s   dataset_archive.zip", (56, 189, 248)),
        ("", (0, 0, 0)),
        ("$ chrome-dl health", (255, 255, 255)),
        ("✓ 桥进程状态: 运行中 (PID 14208)   ✓ 插件配对状态: 正常   ✓ 控制端口: 18888", (34, 197, 94))
    ]

    cy = t_top + 60
    f_term = get_font(15, bold=False)
    for line, color in console_lines:
        if line:
            draw.text((t_left + 30, cy), line, fill=color, font=f_term)
        cy += 24

    img.save(os.path.join(ASSETS_DIR, "screenshot_3.png"), format="PNG")
    print("Screenshot 3 generated.")

def create_icon_128():
    # 128x128 store icon (24-bit PNG, no alpha)
    img = Image.new("RGB", (128, 128), color=(37, 99, 235))
    draw = ImageDraw.Draw(img)

    # Inner circular badge
    draw.ellipse([14, 14, 114, 114], fill=(255, 255, 255))
    draw.ellipse([22, 22, 106, 106], fill=(30, 41, 59))

    # Down arrow
    # Stem
    draw.rectangle([56, 36, 72, 72], fill=(56, 189, 248))
    # Arrow head
    draw.polygon([(40, 70), (88, 70), (64, 94)], fill=(56, 189, 248))

    img.save(os.path.join(ASSETS_DIR, "icon_128.png"), format="PNG")
    print("Icon 128x128 generated.")

if __name__ == "__main__":
    create_screenshot_1()
    create_screenshot_2()
    create_screenshot_3()
    create_icon_128()
